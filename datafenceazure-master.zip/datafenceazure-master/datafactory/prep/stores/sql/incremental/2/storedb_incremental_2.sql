UPDATE [store_orders] SET [sale_price] = '47.65', [currency] = 'CAD', [order_mode] = 'EDIT', [updated_at] = CURRENT_TIMESTAMP WHERE [order_number] = 1501;
UPDATE [store_orders] SET [sale_price] = '32.10', [currency] = 'USD', [order_mode] = 'EDIT', [updated_at] = CURRENT_TIMESTAMP WHERE [order_number] = 2345;
UPDATE [store_orders] SET [sale_price] = '49.78', [currency] = 'USD', [order_mode] = 'EDIT', [updated_at] = CURRENT_TIMESTAMP WHERE [order_number] = 1254;
UPDATE [store_orders] SET [sale_price] = '34.40', [currency] = 'USD', [order_mode] = 'EDIT', [updated_at] = CURRENT_TIMESTAMP WHERE [order_number] = 2234;
UPDATE [store_orders] SET [sale_price] = '93.77', [currency] = 'CAD', [order_mode] = 'EDIT', [updated_at] = CURRENT_TIMESTAMP WHERE [order_number] = 500;
GO