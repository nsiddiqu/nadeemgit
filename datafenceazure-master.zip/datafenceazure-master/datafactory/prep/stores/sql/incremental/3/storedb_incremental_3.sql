UPDATE [store_orders] SET [sale_price] = '47.65', [currency] = 'CAD', [order_mode] = 'DELETE', [updated_at] = CURRENT_TIMESTAMP WHERE [order_number] = 1501;
UPDATE [store_orders] SET [sale_price] = '32.10', [currency] = 'USD', [order_mode] = 'DELETE', [updated_at] = CURRENT_TIMESTAMP WHERE [order_number] = 2345;
GO